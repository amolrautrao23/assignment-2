import React from 'react'
// import notfound from '../img/not-found.svg'
const NotFound = () => {
    return (
        <>
            <div className="error">
                <h2>No User Found!</h2>
            </div>
        </>
    )
}

export default NotFound
