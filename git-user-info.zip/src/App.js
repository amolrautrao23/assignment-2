import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './components/Home'

const App = () => {
  return (
    <>
     <Home/> 
    </>
  )
}

export default App
